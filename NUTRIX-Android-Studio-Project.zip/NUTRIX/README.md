# NUTRIX — One Scan. Complete Nutrition.

A native Android starter project built with Kotlin and Jetpack Compose. It includes the white-and-black NUTRIX interface, camera capture, gallery image selection, and a nutrition-results screen.

## Important status
This is an Android Studio source project, **not a compiled APK**. The camera/gallery flow is implemented. Real AI food recognition is not active until you connect a secure backend that accepts an image at `POST /analyze` and returns JSON in the format below. Do not put private AI-provider API keys inside the Android app.

## Backend response format
```json
{
  "food_name": "Example meal",
  "calories_kcal": 420,
  "protein_g": 22.5,
  "carbs_g": 51.0,
  "fat_g": 13.2,
  "fiber_g": 6.1,
  "sugar_g": 4.0,
  "sodium_mg": 560,
  "other_nutrients": "Potassium: ...; Calcium: ...; Iron: ..."
}
```

All values should be estimates with uncertainty, based on identified foods and estimated portion sizes. A single photo cannot reliably determine exact ingredients, oil, salt, or serving weight.

## Open in Android Studio
1. Install Android Studio (current stable) on a computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `NUTRIX` folder.
4. Let Gradle sync and install Android SDK Platform 35 if prompted.
5. Connect a secure backend and replace `https://YOUR_BACKEND_URL` in `app/build.gradle.kts` with its HTTPS base URL.
6. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk` after a successful build.
