package com.nutrix.app

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.rememberAsyncImagePainter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.DataOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private val Ink = Color(0xFF111111)
private val Muted = Color(0xFF777777)
private val Pale = Color(0xFFF4F4F4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NutrixApp() }
    }
}

@Composable
fun NutrixApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    var result by remember { mutableStateOf<JSONObject?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var cameraUri by remember { mutableStateOf<Uri?>(null) }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) { photoUri = uri; result = null; error = null }
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok && cameraUri != null) { photoUri = cameraUri; result = null; error = null }
    }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Ink, onPrimary = Color.White, background = Color.White,
        surface = Color.White, onSurface = Ink
    )) {
        Column(
            modifier = Modifier.fillMaxSize().background(Color.White)
                .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(18.dp))
            Text("NUTRIX", fontSize = 36.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp, color = Ink)
            Text("ONE SCAN. COMPLETE NUTRITION.", fontSize = 10.sp, letterSpacing = 2.sp, color = Muted)
            Spacer(Modifier.height(54.dp))
            Text("Scan your food.", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text("Know what’s on your plate.", fontSize = 17.sp, color = Muted)
            Spacer(Modifier.height(30.dp))

            if (photoUri == null) {
                Box(
                    modifier = Modifier.fillMaxWidth().height(210.dp)
                        .background(Pale, RoundedCornerShape(24.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("◎", fontSize = 76.sp, color = Ink)
                        Text("YOUR MEAL, ANALYSED", fontSize = 11.sp, letterSpacing = 2.sp, color = Muted)
                    }
                }
            } else {
                Image(
                    painter = rememberAsyncImagePainter(photoUri), contentDescription = "Selected food",
                    modifier = Modifier.fillMaxWidth().height(230.dp), contentScale = ContentScale.Crop
                )
            }
            Spacer(Modifier.height(22.dp))
            Button(
                onClick = {
                    val file = File(context.cacheDir, "images").apply { mkdirs() }
                    val image = File(file, "nutrix_${System.currentTimeMillis()}.jpg")
                    cameraUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", image)
                    camera.launch(cameraUri!!)
                },
                modifier = Modifier.fillMaxWidth().height(58.dp),
                shape = RoundedCornerShape(18.dp), colors = ButtonDefaults.buttonColors(containerColor = Ink)
            ) { Text("TAKE FOOD PHOTO", fontWeight = FontWeight.Bold, letterSpacing = 1.sp) }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = { gallery.launch(ActivityResultContracts.PickVisualMedia.ImageOnly) },
                modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Ink)
            ) { Text("CHOOSE FROM GALLERY", color = Ink, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp) }

            if (photoUri != null) {
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = {
                        val uri = photoUri ?: return@Button
                        loading = true; error = null; result = null
                        scope.launch {
                            try { result = analyseFood(context, uri) }
                            catch (e: Exception) { error = e.message ?: "Could not analyse this image." }
                            finally { loading = false }
                        }
                    },
                    enabled = !loading,
                    modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE9E9E9), contentColor = Ink)
                ) { Text(if (loading) "ANALYSING…" else "ANALYSE NUTRITION", fontWeight = FontWeight.Bold, letterSpacing = 1.sp) }
            }

            if (loading) { Spacer(Modifier.height(20.dp)); CircularProgressIndicator(color = Ink) }
            error?.let {
                Spacer(Modifier.height(16.dp))
                Text(it, color = Color(0xFF9B1C1C), textAlign = TextAlign.Center, fontSize = 13.sp)
            }
            result?.let { NutritionResults(it) }

            Spacer(Modifier.height(36.dp))
            Text("FOOD SCANNING, MADE SIMPLE.", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun NutritionResults(data: JSONObject) {
    val nutrients = listOf(
        "Protein" to "${data.optString("protein_g", "—")} g",
        "Carbohydrates" to "${data.optString("carbs_g", "—")} g",
        "Fats" to "${data.optString("fat_g", "—")} g",
        "Fibre" to "${data.optString("fiber_g", "—")} g",
        "Sugar" to "${data.optString("sugar_g", "—")} g",
        "Sodium" to "${data.optString("sodium_mg", "—")} mg"
    )
    Spacer(Modifier.height(26.dp))
    Text("NUTRITION RESULTS", fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
    Spacer(Modifier.height(10.dp))
    Text("${data.optString("calories_kcal", "—")} kcal", fontSize = 34.sp, fontWeight = FontWeight.Black)
    Text(data.optString("food_name", "Estimated meal nutrition"), color = Muted, fontSize = 14.sp)
    Spacer(Modifier.height(16.dp))
    nutrients.chunked(2).forEach { row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            row.forEach { (name, value) ->
                Column(Modifier.weight(1f).background(Pale, RoundedCornerShape(16.dp)).padding(16.dp)) {
                    Text(name, color = Muted, fontSize = 12.sp)
                    Text(value, color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
    }
    data.optString("other_nutrients").takeIf { it.isNotBlank() }?.let {
        Text("OTHER NUTRIENTS", fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
        Text(it, color = Muted, fontSize = 13.sp)
    }
    Spacer(Modifier.height(8.dp))
    Text("Nutrition values are estimates and can vary with ingredients and portion size.", color = Muted, fontSize = 11.sp)
}

private suspend fun analyseFood(context: Context, uri: Uri): JSONObject = withContext(Dispatchers.IO) {
    require(BuildConfig.API_BASE_URL.startsWith("https://") && !BuildConfig.API_BASE_URL.contains("YOUR_BACKEND_URL")) {
        "The food-analysis service is not connected yet. Add your secure backend URL in app/build.gradle.kts before testing AI analysis."
    }
    val boundary = "NutrixBoundary${System.currentTimeMillis()}"
    val connection = (URL("${BuildConfig.API_BASE_URL.trimEnd('/')}/analyze").openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"; doOutput = true; connectTimeout = 30000; readTimeout = 60000
        setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
    }
    DataOutputStream(connection.outputStream).use { out ->
        out.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"image\"; filename=\"food.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n")
        context.contentResolver.openInputStream(uri)?.use { it.copyTo(out) } ?: error("Cannot read selected image")
        out.writeBytes("\r\n--$boundary--\r\n")
    }
    val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
    val body = stream.bufferedReader().use { it.readText() }
    if (connection.responseCode !in 200..299) error("Analysis service error: $body")
    JSONObject(body)
}
